package draughts;

/**
 * An enum to represent the two Colours a Piece can take.
 */

public enum Colour {
    White, Red
}
